Place code.html and img folder in same folder and run the code.
